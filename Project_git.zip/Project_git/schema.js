const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
  FirstName: String,
  LastName: String,
  Password: String,
  Email: String,
  MobileNo: Number,
  Gender: String,
  Designation: String,
});

module.exports = mongoose.model("data", productSchema);
