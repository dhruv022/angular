const firstName = document.getElementById("fname");
const errorElement1 = document.getElementById("validFname");

firstName.addEventListener("blur", (event) => {
  let regex = /^[a-zA-Z]{3,15}$/;
  if (!regex.test(event.target.value)) {
    errorElement1.innerText =
      "First name must be between 3 and 15 characters and contain only letters.";
    firstName.classList.remove("is-valid");
    firstName.classList.add("is-invalid");
  } else {
    errorElement1.innerText = "";
    firstName.classList.remove("is-invalid");
    firstName.classList.add("is-valid");
  }
});

firstName.addEventListener("input", (event) => {
  let regex = /^[a-zA-Z]{3,15}$/;
  if (!regex.test(event.target.value)) {
    errorElement1.innerText =
      "First name must be between 3 and 15 characters and contain only letters.";
    firstName.classList.remove("is-valid");
    firstName.classList.add("is-invalid");
  } else {
    errorElement1.innerText = "";
    firstName.classList.remove("is-invalid");
    firstName.classList.add("is-valid");
  }
});

const lastName = document.getElementById("lname");
const errorElement2 = document.getElementById("validLname");

lastName.addEventListener("blur", (event) => {
  let regex = /^[a-zA-Z]{3,15}$/;
  if (!regex.test(event.target.value)) {
    errorElement2.innerText =
      "Last name must be between 3 and 15 characters and contain only letters.";
    lastName.classList.remove("is-valid");
    lastName.classList.add("is-invalid");
  } else {
    errorElement2.innerText = "";
    lastName.classList.remove("is-invalid");
    lastName.classList.add("is-valid");
  }
});

lastName.addEventListener("input", (event) => {
  let regex = /^[a-zA-Z]{3,15}$/;
  if (!regex.test(event.target.value)) {
    errorElement2.innerText =
      "Last name must be between 3 and 15 characters and contain only letters.";
    lastName.classList.remove("is-valid");
    lastName.classList.add("is-invalid");
  } else {
    errorElement2.innerText = "";
    lastName.classList.remove("is-invalid");
    lastName.classList.add("is-valid");
  }
});

const email = document.getElementById("email");
const errorElement3 = document.getElementById("validEmail");

email.addEventListener("blur", (event) => {
  let regex =
    /^[a-zA-Z0-9.!#$%&'+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)$/;
  if (!regex.test(event.target.value)) {
    errorElement3.innerText = "Please enter valid email ID";
    email.classList.remove("is-valid");
    email.classList.add("is-invalid");
  } else {
    errorElement3.innerText = "";
    email.classList.remove("is-invalid");
    email.classList.add("is-valid");
  }
});

email.addEventListener("input", (event) => {
  let regex =
    /^[a-zA-Z0-9.!#$%&'+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)$/;
  if (!regex.test(event.target.value)) {
    errorElement3.innerText = "Please enter valid email ID";
    email.classList.remove("is-valid");
    email.classList.add("is-invalid");
  } else {
    errorElement3.innerText = "";
    email.classList.remove("is-invalid");
    email.classList.add("is-valid");
  }
});

const contact = document.getElementById("contact");
const errorElement4 = document.getElementById("validContact");
contact.addEventListener("blur", (event) => {
  let regex = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
  // Formats supported by above expression
  //+91-123-456-7890
  //+911234567890
  //091-1234-567-890
  //091234567890
  //7123456789
  //8123456789
  //9123456789

  if (!regex.test(event.target.value)) {
    errorElement4.innerText = "Please enter only Indian mobile number";
    contact.classList.remove("is-valid");
    contact.classList.add("is-invalid");
  } else {
    errorElement4.innerText = "";
    contact.classList.remove("is-invalid");
    contact.classList.add("is-valid");
  }
});
contact.addEventListener("input", (event) => {
  let regex = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
  if (!regex.test(event.target.value)) {
    errorElement4.innerText = "Please enter only Indian mobile number";
    contact.classList.remove("is-valid");
    contact.classList.add("is-invalid");
  } else {
    errorElement4.innerText = "";
    contact.classList.remove("is-invalid");
    contact.classList.add("is-valid");
  }
});

const password = document.getElementById("password");
const errorElement5 = document.getElementById("validPass");
password.addEventListener("blur", (event) => {
  let regex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,14}$/;
  if (!regex.test(event.target.value)) {
    errorElement5.innerText =
      "Password should contain minimum 1 character, 1 number and length should be between 8 to 14 characters long ";
    password.classList.remove("is-valid");
    password.classList.add("is-invalid");
  } else {
    errorElement5.innerText = "";
    password.classList.remove("is-invalid");
    password.classList.add("is-valid");
  }
});

password.addEventListener("input", (event) => {
  let regex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,14}$/;
  if (!regex.test(event.target.value)) {
    errorElement5.innerText =
      "Password should contain minimum 1 character, 1 number and length should be between 8 to 14 characters long ";
    password.classList.remove("is-valid");
    password.classList.add("is-invalid");
  } else {
    errorElement5.innerText = "";
    password.classList.remove("is-invalid");
    password.classList.add("is-valid");
  }
});

const password2 = document.getElementById("password");
const confirmPassword = document.getElementById("confirmPassword");
const errorElement6 = document.getElementById("validCpass");
let regex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,14}$/;
confirmPassword.addEventListener("blur", (event) => {
  if (event.target.value !== password2.value) {
    errorElement6.innerText = "Passwords do not match";
    confirmPassword.classList.remove("is-valid");
    confirmPassword.classList.add("is-invalid");
  } else if (!regex.test(event.target.value)) {
    errorElement6.innerText =
      "Password should contain minimum 1 character, 1 number and length should be between 8 to 14 characters long ";
    confirmPassword.classList.remove("is-valid");
    confirmPassword.classList.add("is-invalid");
  } else {
    errorElement6.innerText = "";
    confirmPassword.classList.remove("is-invalid");
    confirmPassword.classList.add("is-valid");
  }
});
confirmPassword.addEventListener("input", (event) => {
  if (event.target.value !== password2.value) {
    errorElement6.innerText = "Passwords do not match";
    confirmPassword.classList.remove("is-valid");
    confirmPassword.classList.add("is-invalid");
  } else {
    errorElement6.innerText = "";
    confirmPassword.classList.remove("is-invalid");
    confirmPassword.classList.add("is-valid");
  }
});
