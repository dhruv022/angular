const express = require("express");
require("./database");
const Schema = require("./schema");
const path = require("path");
const staticPath = path.join(__dirname, "Public");
const app = express();
app.set("view engine", "ejs");
app.use(express.static(staticPath));
app.use(express.urlencoded({ extended: false }));

//render index.ejs page
app.get("/", (req, res) => {
  res.render("index");
});


//API for post data of Signup form
app.post("/", async (req, res) => {
  console.log(req.body);
  FirstName= req.body.fname;
  LastName= req.body.lname;
  Password= req.body.pass;
  Email= req.body.email;
  MobileNo= req.body.contact;
  Gender= req.body.gender;
  Designation= req.body.Designation;
  const insertUser = new Schema({
    FirstName: req.body.fname,
    LastName: req.body.lname,
    Password: req.body.pass,
    Email: req.body.email,
    MobileNo: req.body.contact,
    Gender: req.body.gender,
    Designation: req.body.Designation,
  });

if(FirstName!= "" && LastName!= "" && Email!= "" && MobileNo!= "" && Password!= ""){
  await insertUser.save();
  // render success.ejs page

  resp.render("sucess");
}else{
  resp.render("alert");
}

});

console.log("App is listening on port :" + 4500);
app.listen(4500);
